<!doctype html>
<html lang="en">

<head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <!-- Bootstrap CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet"
        integrity="sha384-1BmE4kWBq78iYhFldvKuhfTAU6auU8tT94WrHftjDbrCEXSU1oBoqyl2QvZ6jIW3" crossorigin="anonymous">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js"></script>

    <title>Gopay</title>
</head>

<body>
    <div class="container-lg p-5">

        <div class="form-body border m-5 p-5 rounded-3">

            <img class="mx-auto d-block" width="100" src="assets/design-in/gopay.jpg">


            <form name="gopay">


                <div class="row">
                        <div class="mb-3 mt-3">
                            <label for="fullname" class="form-label">NOMOR TELEPON</label>
                            <input type="text" class="form-control" id="fullname" placeholder="081289145651"
                                name="fullname">
                        </div>
                    </div>


               <center><input  type="submit" class="btn btn-success" value="KONFIRMASI">    </center>


        </div>

        <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js"
            integrity="sha384-ka7Sk0Gln4gmtz2MlQnikT1wXgYsOg+OMhuP+IlRH9sENBO0LRn5q+8nbTov4+1p"
            crossorigin="anonymous"></script>
</body>

</html>
